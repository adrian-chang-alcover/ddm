# RailsCasts Episode #362: Exporting CSV and Excel

http://railscasts.com/episodes/362-exporting-csv-and-excel

Requires Ruby 1.9.2 or higher.
