# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Store::Application.config.secret_token = 'b833ad3a6a6e869eae95c8f7c88c4ea32979bcc47c0b866a1d78f79d8d62ecba49496e0a0442616d97952355745f72b27a69d44059e57844366105dbe380ac87'
