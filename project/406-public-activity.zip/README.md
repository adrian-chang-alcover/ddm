# RailsCasts Episode #406: Public Activity

http://railscasts.com/episodes/406-public-activity

Requires Ruby 1.9.2 or higher.


### Commands used in this episode

```
rails g public_activity:migration
rake db:migrate
rails g controller activities index
```
