require 'test_helper'

class RecipesHelperTest < ActionView::TestCase
end
