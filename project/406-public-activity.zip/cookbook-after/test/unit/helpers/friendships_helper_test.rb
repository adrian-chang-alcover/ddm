require 'test_helper'

class FriendshipsHelperTest < ActionView::TestCase
end
