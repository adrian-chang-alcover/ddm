# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cookbook::Application.config.secret_token = 'a18046510f9a9ce7a06c2e81e52a761526c212933e924afd73621e85a48bfba03d463515586df31ad73e75f9ca3a8ee2a89dc8136a2bfe71bde17f87717427ec'
